function computeSum(a, b) {
    if (a === b) {
      return 3 * (a + b); 
    } else {
      return a + b; 
    }
  }
  
 
  console.log(computeSum(5, 5)); 
  console.log(computeSum(4, 7)); 
  