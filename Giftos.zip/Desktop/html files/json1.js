var mobJson = `{
    "productId": 1001,
    "product": {
      "name": "Moto",
      "series": "G5+",
      "color": "NightSky"
    },
    "price": 14900,
    "category": "Electronics",
    "shippingDetails": {
      "shipmentNo": "1DEL009",
      "company": "Intel Marketing",
      "receivedOn": "2018-6-19"
    },
    "seller": {
      "name": "xyz Mobile",
      "location": "New York",
      "stock": 17
    }
  }`;
  
  // Parse the JSON string
  var mobData = JSON.parse(mobJson);
  
  // Construct the output string
  var output = `${mobData.seller.name} shipped a ${mobData.product.name} ${mobData.product.series} worth ${mobData.price} with productId: ${mobData.productId}.`;
  
  // Print the output to console
  console.log(output);
  