function greet(){
    var hello=function welcome(){console.log("Hello World");}
    return hello;
}
var retFunc=greet();
retFunc();

function hello(fun){
    fun();

}
function sayHi(){
    console.log("Hii   ")
}
hello(sayHi);
hello(function(){console.log("Function.........")});