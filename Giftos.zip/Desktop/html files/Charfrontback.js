function addFirstCharFrontAndBack(str) {
    if (str.length === 0) {
      return ""; 
    }
    
    const firstChar = str.charAt(0); 
    return firstChar + str + firstChar; 
  }
  
  
  console.log(addFirstCharFrontAndBack("hello")); 
  console.log(addFirstCharFrontAndBack("a"));     
  console.log(addFirstCharFrontAndBack(""));      
  