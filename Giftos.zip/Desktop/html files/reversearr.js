function reverseArray(arr) {
    if (arr.length !== 3) {
      throw new Error("Array must have exactly 3 elements."); 
    }
    
    return arr.reverse(); 
  }
  
 
  console.log(reverseArray([1, 2, 3])); 
  console.log(reverseArray([10, 20, 30])); 
  