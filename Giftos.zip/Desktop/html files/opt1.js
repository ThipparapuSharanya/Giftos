function calculateMaxPower(V, RS, RL) {
    if (RS === RL) {
        return Math.pow(V, 2) / (4 * RS);
    } else {
        console.log("For maximum power transfer, RS must equal RL.");
        return 0;
    }
}
const voltage = 10;  
const sourceResistance = 5;  
const loadResistance = 5;  
const maxPower = calculateMaxPower(voltage, sourceResistance, loadResistance);
console.log("Maximum Power Transfer:", maxPower, "Watts");

 