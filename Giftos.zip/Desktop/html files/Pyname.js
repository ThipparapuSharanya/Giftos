function addPyPrefix(str) {
    if (str.startsWith("Py")) {
      return str; 
    } else {
      return "Py" + str; 
    }
  }
  
  
  console.log(addPyPrefix("Python")); 
  console.log(addPyPrefix("thon"));   
  console.log(addPyPrefix("Pyro"));   
  