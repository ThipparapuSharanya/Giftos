const Person1 = {
    Name: "John Doe",
    ContactNo: "+1234567890",
    Address: "123 Main St, Springfield, USA",
    
    Display: function () {
      console.log("Name:", this.Name);
      console.log("Contact No:", this.ContactNo);
      console.log("Address:", this.Address);
    }
  };
  
  
  Person1.Display();
  