function sumOfFirstTenNumbers() {
    let sum = 0;
    for (let i = 1; i <= 10; i++) {
        sum += i;
    }
    return sum;
}

const result = sumOfFirstTenNumbers();
console.log("The sum of the first 10 numbers is:", result);
