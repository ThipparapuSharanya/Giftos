function maxAdjacentDifference(arr) {
    if (arr.length < 2) {
      throw new Error("Array must have at least two elements.");
    }
  
    let maxDifference = 0;
  
    for (let i = 0; i < arr.length - 1; i++) {
      const difference = Math.abs(arr[i] - arr[i + 1]);
      maxDifference = Math.max(maxDifference, difference);
    }
  
    return maxDifference;
  }
  
  
  console.log(maxAdjacentDifference([2, 4, 1, 0])); 
  console.log(maxAdjacentDifference([10, 20, 30, 50])); 
  console.log(maxAdjacentDifference([-5, 15, 25, -10])); 
  