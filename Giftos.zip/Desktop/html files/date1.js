function formatDate(date, format) {
  const options = {
    "YYYY-MM-DD": date.toISOString().split("T")[0],
    "MM/DD/YYYY": `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`,
    "DD-MM-YYYY": `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`,
  };

  return options[format];
}

function printDates() {
  const today = new Date();
  const afterFiveDays = new Date();
  afterFiveDays.setDate(today.getDate() + 5);

  console.log("Today's Date:");
  console.log("YYYY-MM-DD:", formatDate(today, "YYYY-MM-DD"));
  console.log("MM/DD/YYYY:", formatDate(today, "MM/DD/YYYY"));
  console.log("DD-MM-YYYY:", formatDate(today, "DD-MM-YYYY"));

  console.log("\nDate After 5 Days:");
  console.log("YYYY-MM-DD:", formatDate(afterFiveDays, "YYYY-MM-DD"));
  console.log("MM/DD/YYYY:", formatDate(afterFiveDays, "MM/DD/YYYY"));
  console.log("DD-MM-YYYY:", formatDate(afterFiveDays, "DD-MM-YYYY"));
}

printDates();
  