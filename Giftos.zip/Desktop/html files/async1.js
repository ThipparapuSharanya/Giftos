function display(){
    console.log("Let's go to Trip");
};
console.log("Before");
setTimeout(display,3000)
console.log("After");
