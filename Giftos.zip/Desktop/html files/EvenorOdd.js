function checkOddOrEven(number) {
    if (number % 2 === 0) {
        return "Even";
    } else {
        return "Odd";
    }
}

const number = 7;
const result = checkOddOrEven(number);
console.log(`The number ${number} is ${result}.`);
