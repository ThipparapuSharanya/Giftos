const Person1 = {
    Name: "John Doe",
    ContactNo: "+1234567890",
    Address: "123 Main St, Springfield, USA",
    
    Display: function () {
      console.log("Name:", this.Name);
      console.log("Contact No:", this.ContactNo);
      console.log("Address:", this.Address);
    }
  };
  
  const Person2 = {
    Name: "Jane Smith",
    ContactNo: "+0987654321",
    Address: "456 Elm St, Metropolis, USA"
  };
  
  
  Person1.Display.call(Person2);
  