class Employee {
    
    constructor(E_Id, Name, Designation) {
      this.E_Id = E_Id;
      this.Name = Name;
      this.Designation = Designation;
    }
  
    
    Show() {
      console.log("Employee ID:", this.E_Id);
      console.log("Name:", this.Name);
      console.log("Designation:", this.Designation);
      console.log("Salary:", this.Salary);
      console.log("Bonus:", this.Bonus);
      console.log("---------------------------");
    }
  }
  
  
  Employee.prototype.Salary = 0; 
  Employee.prototype.Bonus = 0;  
  
  Employee.prototype.dissal = function () {
    console.log(`Employee ${this.Name} (ID: ${this.E_Id}) has been dismissed.`);
  };
  
  
  const employee1 = new Employee(101, "John Doe", "Software Engineer");
  const employee2 = new Employee(102, "Jane Smith", "Project Manager");
  const employee3 = new Employee(103, "David Lee", "HR Specialist");
  
  
  employee1.Salary = 50000;
  employee1.Bonus = 5000;
  
  employee2.Salary = 75000;
  employee2.Bonus = 8000;
  
  employee3.Salary = 45000;
  employee3.Bonus = 3000;
  
  
  employee1.Show();
  employee2.Show();
  employee3.Show();
  
  
  employee1.dissal();
  
  