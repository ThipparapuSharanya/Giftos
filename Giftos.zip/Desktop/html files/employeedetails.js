class Employee {
    
    constructor(E_Id, Name, Designation) {
      this.E_Id = E_Id;
      this.Name = Name;
      this.Designation = Designation;
    }
  
    
    Show() {
      console.log("Employee ID:", this.E_Id);
      console.log("Name:", this.Name);
      console.log("Designation:", this.Designation);
      console.log("---------------------------");
    }
  }
  
  
  const employee1 = new Employee(101, "John Doe", "Software Engineer");
  const employee2 = new Employee(102, "Jane Smith", "Project Manager");
  const employee3 = new Employee(103, "David Lee", "HR Specialist");
  
  
  employee1.Show();
  employee2.Show();
  employee3.Show();
  
  