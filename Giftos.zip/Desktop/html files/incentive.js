
class Employee {
    
    constructor(E_Id, Name, Designation) {
      this.E_Id = E_Id;
      this.Name = Name;
      this.Designation = Designation;
      this.Salary = 0; 
    }
  
    
    Show() {
      console.log("Employee ID:", this.E_Id);
      console.log("Name:", this.Name);
      console.log("Designation:", this.Designation);
      console.log("Salary:", this.Salary);
      console.log("---------------------------");
    }
  }
  
  
  class Manager extends Employee {
    
    constructor(E_Id, Name, Designation, Salary, incentive) {
      super(E_Id, Name, Designation); 
      this.Salary = Salary; 
      this.incentive = incentive; 
    }
  
    
    totalsal() {
      const totalSalary = this.Salary + this.incentive;
      console.log(`Total Salary for Manager ${this.Name}: ${totalSalary}`);
      console.log("---------------------------");
    }
  }
  
  
  const manager1 = new Manager(201, "Alice Brown", "General Manager", 100000, 20000);
  
  
  manager1.Show();
  manager1.totalsal();
  