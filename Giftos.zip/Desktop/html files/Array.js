// Function to sort an array of numbers
function sortArray(numbers) {
    return numbers.sort((a, b) => a - b);
}

// Example usage
const numbers = [34, 7, 23, 32, 5, 62];
const sortedNumbers = sortArray(numbers);

console.log("Sorted Array:", sortedNumbers);
